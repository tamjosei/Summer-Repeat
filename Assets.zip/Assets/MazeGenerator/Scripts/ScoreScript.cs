﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class ScoreScript : MonoBehaviour
{

    public static int scoreValue = 0;
    public static int nextLevelScore = 25;

    Text score;

    // Start is called before the first frame update
    void Start()
    {
        score = GetComponent<Text>();
    }


    // Update is called once per frame
    void Update()
    
        ///if(scoreValue == nextLevelScore)
        
            // SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        
    

    {
        score.text = "Score: " + scoreValue;
    }

}
    //I am meant to have code that when a certain score is reached it loads level 2 and when the score is met on level 2 it takes you to the end of the game, but everytime I try and code it I get errors.